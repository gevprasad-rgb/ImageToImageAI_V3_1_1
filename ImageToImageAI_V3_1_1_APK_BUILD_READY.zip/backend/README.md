# ImageToImageAI V3 Gateway

This gateway converts the Android app's simple multipart request into a ComfyUI image-to-image workflow.

## 1. Install ComfyUI
Install ComfyUI on a machine with a supported GPU and place a compatible checkpoint in ComfyUI's `models/checkpoints` directory.

The reference workflow uses the standard `CheckpointLoaderSimple + VAEEncode + KSampler + VAEDecode` image-to-image graph. ComfyUI's current server exposes `/prompt`, `/history/{prompt_id}`, `/view`, `/upload/image` and related server endpoints used by this gateway. See the official ComfyUI API examples for the same queue → history → image pattern.

## 2. Start ComfyUI
Run ComfyUI so that it listens on the local machine, normally:

    http://127.0.0.1:8188

## 3. Start this gateway
From this directory:

Linux/macOS:

    python3 -m venv .venv
    . .venv/bin/activate
    pip install -r requirements.txt
    export COMFYUI_URL=http://127.0.0.1:8188
    export COMFYUI_CHECKPOINT=sd_xl_base_1.0.safetensors
    python server.py

Windows PowerShell:

    py -m venv .venv
    .\.venv\Scripts\Activate.ps1
    pip install -r requirements.txt
    $env:COMFYUI_URL="http://127.0.0.1:8188"
    $env:COMFYUI_CHECKPOINT="sd_xl_base_1.0.safetensors"
    python server.py

The gateway listens on `0.0.0.0:8000` in Docker. For an Android release APK, use HTTPS. Debug APKs can explicitly use the app's Trusted LAN HTTP setting for private/loopback development hosts.

    http://YOUR-PC-LAN-IP:8000

## 4. Connect the APK
Open ImageToImageAI V3 → Provider / Settings and enter the gateway URL. Press **Backend** to test, then **Refresh models**.

## 5. Model selection
The gateway reads the checkpoint choices exposed by ComfyUI's `CheckpointLoaderSimple`. Different checkpoints have different visual characteristics. Install only models you are licensed to use.

## Security
For non-loopback gateway binds (including Docker `0.0.0.0`), `APP_TOKEN` is required. The gateway also applies a per-client generation rate limit and a persistent clientRequestId idempotency ledger. Do not expose it directly to the public internet without TLS, authentication, rate limiting and an appropriate reverse proxy/firewall boundary.

## Quality expectations
This package provides a stronger image-to-image product architecture, but no Android client can guarantee that its local output will match a proprietary hosted service. Image quality depends on the checkpoint, VAE, GPU/VRAM, workflow and tuning.


## V3 task contract
- `GET /capabilities` advertises only real supported tasks.
- `TEXT_TO_IMAGE` requires no source image.
- `IMAGE_TO_IMAGE` requires a source image.
- `client_request_id` is preserved end-to-end for lineage.
- Unsupported task IDs are rejected rather than silently substituted.
