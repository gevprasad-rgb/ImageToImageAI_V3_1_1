import io
import hashlib
import hmac
import sqlite3
import threading
from collections import deque
import json
import os
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

import requests
from fastapi import FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse, Response
from PIL import Image, ImageOps

COMFY_URL = os.getenv("COMFYUI_URL", "http://127.0.0.1:8188").rstrip("/")
HOST = os.getenv("HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", "8000"))
DEFAULT_MODEL = os.getenv("COMFYUI_CHECKPOINT", "sd_xl_base_1.0.safetensors")
APP_TOKEN = os.getenv("APP_TOKEN", "").strip()
TIMEOUT = int(os.getenv("GENERATION_TIMEOUT", "900"))
MAX_SOURCE_BYTES = int(os.getenv("MAX_SOURCE_BYTES", "15000000"))
MAX_OUTPUT_BYTES = int(os.getenv("MAX_OUTPUT_BYTES", "25000000"))
MAX_PROMPT_CHARS = int(os.getenv("MAX_PROMPT_CHARS", "10000"))
MAX_CLIENT_REQUEST_ID_CHARS = int(os.getenv("MAX_CLIENT_REQUEST_ID_CHARS", "128"))
MAX_RATE_REQUESTS = int(os.getenv("MAX_RATE_REQUESTS", "20"))
RATE_WINDOW_SECONDS = int(os.getenv("RATE_WINDOW_SECONDS", "60"))
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "./backend_runtime"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = UPLOAD_DIR / "gateway_jobs.sqlite3"
RATE_LOCK = threading.Lock()
RATE_BUCKETS: dict[str, deque[float]] = {}

app = FastAPI(title="ImageToImageAI V3.1 Gateway", version="3.1.0")

SUPPORTED_RATIOS = ["1:1", "9:16", "16:9", "4:5", "3:4"]
SUPPORTED_TASKS = ["TEXT_TO_IMAGE", "IMAGE_TO_IMAGE"]


def is_loopback_host(value: str) -> bool:
    return value in {"127.0.0.1", "localhost", "::1"}


def auth(x_app_token: Optional[str]) -> None:
    if not APP_TOKEN:
        if is_loopback_host(HOST):
            return
        raise HTTPException(status_code=503, detail="Gateway authentication is required for non-local deployments")
    if not x_app_token or not hmac.compare_digest(x_app_token, APP_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid backend access token")


def rate_limit(client_host: str) -> None:
    now = time.time()
    with RATE_LOCK:
        bucket = RATE_BUCKETS.setdefault(client_host or "unknown", deque())
        while bucket and now - bucket[0] >= RATE_WINDOW_SECONDS:
            bucket.popleft()
        if len(bucket) >= MAX_RATE_REQUESTS:
            raise HTTPException(status_code=429, detail="Generation rate limit exceeded; try again shortly")
        bucket.append(now)


@contextmanager
def db_conn():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS gateway_jobs (
            client_request_id TEXT PRIMARY KEY,
            request_hash TEXT NOT NULL,
            prompt_id TEXT,
            status TEXT NOT NULL,
            filename TEXT,
            subfolder TEXT,
            folder_type TEXT,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        )""")
        conn.commit()
        yield conn
    finally:
        conn.close()


def get_job(client_request_id: str):
    with db_conn() as conn:
        return conn.execute("SELECT client_request_id, request_hash, prompt_id, status, filename, subfolder, folder_type, created_at, updated_at FROM gateway_jobs WHERE client_request_id = ?", (client_request_id,)).fetchone()


def put_job(client_request_id: str, request_hash: str, status: str, prompt_id: Optional[str] = None,
            filename: Optional[str] = None, subfolder: Optional[str] = None, folder_type: Optional[str] = None) -> None:
    now = time.time()
    with db_conn() as conn:
        conn.execute("""INSERT INTO gateway_jobs (client_request_id, request_hash, prompt_id, status, filename, subfolder, folder_type, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(client_request_id) DO UPDATE SET
                       request_hash=excluded.request_hash, prompt_id=excluded.prompt_id, status=excluded.status,
                       filename=excluded.filename, subfolder=excluded.subfolder, folder_type=excluded.folder_type,
                       created_at=gateway_jobs.created_at, updated_at=excluded.updated_at""",
                     (client_request_id, request_hash, prompt_id, status, filename, subfolder, folder_type, now, now))
        conn.commit()


def claim_job(client_request_id: str, request_hash_value: str) -> tuple[bool, tuple | None]:
    """Atomically reserve a clientRequestId before any provider submission.

    Returns (claimed, row). A false claim means another request already owns the id.
    The caller must compare request hashes before proceeding, then honor the stored state.
    """
    now = time.time()
    with db_conn() as conn:
        conn.execute("""INSERT OR IGNORE INTO gateway_jobs
                       (client_request_id, request_hash, prompt_id, status, filename, subfolder, folder_type, created_at, updated_at)
                       VALUES (?, ?, NULL, 'SUBMITTING', NULL, NULL, NULL, ?, ?)""",
                     (client_request_id, request_hash_value, now, now))
        row = conn.execute("SELECT client_request_id, request_hash, prompt_id, status, filename, subfolder, folder_type, created_at, updated_at FROM gateway_jobs WHERE client_request_id = ?",
                           (client_request_id,)).fetchone()
        conn.commit()
    return row is not None and row[1] == request_hash_value and row[3] == 'SUBMITTING' and row[2] is None and row[4] is None, row


def request_hash(task_id: str, prompt: str, negative_prompt: str, aspect_ratio: str, profile: str,
                 model: str, preserve: int, cfg: float, steps: int, seed: int, image_bytes: Optional[bytes]) -> str:
    h = hashlib.sha256()
    parts = [task_id, prompt, negative_prompt, aspect_ratio, profile, model, str(preserve), str(cfg), str(steps), str(seed)]
    h.update("\n".join(parts).encode("utf-8"))
    if image_bytes is not None:
        h.update(hashlib.sha256(image_bytes).digest())
    return h.hexdigest()


def comfy_get(path: str, timeout: int = 20):
    return requests.get(COMFY_URL + path, timeout=timeout, allow_redirects=False)


def comfy_post(path: str, payload=None, files=None, data=None, timeout: int = 60):
    return requests.post(COMFY_URL + path, json=payload, files=files, data=data, timeout=timeout, allow_redirects=False)


def target_size(aspect_ratio: str) -> tuple[int, int]:
    table = {
        "1:1": (1024, 1024),
        "9:16": (768, 1344),
        "16:9": (1344, 768),
        "4:5": (896, 1120),
        "3:4": (896, 1152),
    }
    if aspect_ratio not in table:
        raise HTTPException(status_code=400, detail="Unsupported aspect ratio")
    return table[aspect_ratio]


SUPPORTED_PROFILES = ["Balanced", "Source Preserve", "Creative Transform", "High Detail"]


def profile_settings(profile: str, preserve_percent: int, cfg: float, steps: int):
    if profile not in SUPPORTED_PROFILES:
        raise HTTPException(status_code=400, detail="Unsupported generation profile")
    if not 5 <= preserve_percent <= 95:
        raise HTTPException(status_code=400, detail="Preservation must be between 5 and 95")
    if not 1.0 <= cfg <= 10.0:
        raise HTTPException(status_code=400, detail="Prompt adherence must be between 1.0 and 10.0")
    if not 12 <= steps <= 60:
        raise HTTPException(status_code=400, detail="Quality steps must be between 12 and 60")
    denoise = max(0.05, min(0.95, 1.0 - (preserve_percent / 100.0)))
    if profile == "Source Preserve":
        denoise = min(denoise, 0.34)
        steps = max(steps, 28)
    elif profile == "Creative Transform":
        denoise = max(denoise, 0.62)
        steps = max(steps, 30)
    elif profile == "High Detail":
        steps = max(steps, 42)
        denoise = min(0.82, denoise + 0.04)
    else:
        steps = max(12, min(60, steps))
    return denoise, max(1.0, min(10.0, cfg)), max(12, min(60, steps))


def preprocess_image(raw: bytes, aspect_ratio: str) -> tuple[bytes, str]:
    try:
        image = Image.open(io.BytesIO(raw))
        if image.width <= 0 or image.height <= 0 or image.width * image.height > 80_000_000:
            raise ValueError("source image dimensions are too large")
        image = image.convert("RGB")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid source image: {exc}")
    width, height = target_size(aspect_ratio)
    image = ImageOps.fit(image, (width, height), method=Image.Resampling.LANCZOS, centering=(0.5, 0.5))
    out = io.BytesIO()
    image.save(out, format="PNG", optimize=True)
    result = out.getvalue()
    if len(result) > MAX_SOURCE_BYTES:
        raise HTTPException(status_code=413, detail="Processed source image is too large")
    return result, f"i2i_{uuid.uuid4().hex}.png"


def upload_to_comfy(image_bytes: bytes, filename: str) -> str:
    files = {"image": (filename, image_bytes, "image/png")}
    data = {"overwrite": "true", "type": "input", "subfolder": "image_to_image_ai"}
    r = comfy_post("/upload/image", files=files, data=data, timeout=90)
    if r.status_code >= 400:
        raise HTTPException(status_code=502, detail=f"ComfyUI image upload failed ({r.status_code}): {r.text[:500]}")
    obj = r.json()
    name = obj.get("name") or filename
    subfolder = obj.get("subfolder", "")
    return f"{subfolder}/{name}" if subfolder else name


def workflow_txt2img(prompt: str, negative_prompt: str, model: str,
                     seed: int, steps: int, cfg: float, width: int, height: int):
    return {
        "10": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": model}},
        "20": {"class_type": "EmptyLatentImage", "inputs": {"width": width, "height": height, "batch_size": 1}},
        "30": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["10", 1], "text": prompt}},
        "31": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["10", 1], "text": negative_prompt or ""}},
        "50": {"class_type": "KSampler", "inputs": {
            "seed": seed, "steps": steps, "cfg": cfg, "sampler_name": "dpmpp_2m",
            "scheduler": "karras", "denoise": 1.0, "model": ["10", 0],
            "positive": ["30", 0], "negative": ["31", 0], "latent_image": ["20", 0]
        }},
        "60": {"class_type": "VAEDecode", "inputs": {"samples": ["50", 0], "vae": ["10", 2]}},
        "70": {"class_type": "SaveImage", "inputs": {"filename_prefix": "ImageToImageAI_V3", "images": ["60", 0]}}
    }


def workflow_i2i(image_name: str, prompt: str, negative_prompt: str, model: str,
                 seed: int, steps: int, cfg: float, denoise: float, width: int, height: int):
    return {
        "10": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": model}},
        "20": {"class_type": "LoadImage", "inputs": {"image": image_name}},
        "30": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["10", 1], "text": prompt}},
        "31": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["10", 1], "text": negative_prompt or ""}},
        "40": {"class_type": "VAEEncode", "inputs": {"pixels": ["20", 0], "vae": ["10", 2]}},
        "50": {"class_type": "KSampler", "inputs": {
            "seed": seed, "steps": steps, "cfg": cfg, "sampler_name": "dpmpp_2m",
            "scheduler": "karras", "denoise": denoise, "model": ["10", 0],
            "positive": ["30", 0], "negative": ["31", 0], "latent_image": ["40", 0]
        }},
        "60": {"class_type": "VAEDecode", "inputs": {"samples": ["50", 0], "vae": ["10", 2]}},
        "70": {"class_type": "SaveImage", "inputs": {"filename_prefix": "ImageToImageAI_V3", "images": ["60", 0]}}
    }


def queue_prompt(graph: dict, client_id: str) -> str:
    r = comfy_post("/prompt", payload={"prompt": graph, "client_id": client_id}, timeout=60)
    if r.status_code >= 400:
        raise HTTPException(status_code=502, detail=f"ComfyUI queue rejected job ({r.status_code}): {r.text[:600]}")
    obj = r.json()
    if "error" in obj:
        raise HTTPException(status_code=502, detail=f"ComfyUI error: {json.dumps(obj['error'])[:600]}")
    prompt_id = obj.get("prompt_id")
    if not prompt_id:
        raise HTTPException(status_code=502, detail="ComfyUI did not return a prompt_id")
    return prompt_id


def get_history(prompt_id: str) -> dict:
    r = comfy_get(f"/history/{prompt_id}", timeout=30)
    if r.status_code >= 400:
        raise HTTPException(status_code=502, detail=f"ComfyUI history failed ({r.status_code})")
    return r.json()


def wait_for_image(prompt_id: str) -> tuple[str, str, str]:
    deadline = time.time() + TIMEOUT
    while time.time() < deadline:
        history = get_history(prompt_id)
        item = history.get(prompt_id)
        if item:
            status = item.get("status") or {}
            status_str = str(status.get("status_str", "")).lower()
            if status_str in {"error", "failed"} or status.get("completed") is False and status_str in {"error", "failed"}:
                detail = "ComfyUI generation failed"
                messages = status.get("messages") or []
                if messages:
                    detail = f"ComfyUI generation failed: {json.dumps(messages)[:700]}"
                raise HTTPException(status_code=502, detail=detail)
            if item.get("outputs"):
                for node_output in item["outputs"].values():
                    for image in node_output.get("images", []):
                        filename = image.get("filename", "")
                        if filename:
                            return filename, image.get("subfolder", ""), image.get("type", "output")
            if status.get("completed") and status_str not in {"", "success"}:
                raise HTTPException(status_code=502, detail=f"ComfyUI returned terminal status: {status_str}")
        time.sleep(0.8)
    raise HTTPException(status_code=504, detail="Generation timed out while waiting for ComfyUI; job remains reconcilable")


def validate_png_bytes(data: bytes) -> tuple[int, int]:
    if not data or len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n":
        raise HTTPException(status_code=502, detail="Provider output is not a valid PNG")
    try:
        with Image.open(io.BytesIO(data)) as image:
            if image.format != "PNG":
                raise ValueError("format is not PNG")
            width, height = image.size
            if width <= 0 or height <= 0 or width > 8192 or height > 8192:
                raise ValueError("dimensions are invalid")
            if width * height > 80_000_000:
                raise ValueError("pixel count is too large")
            image.verify()
        with Image.open(io.BytesIO(data)) as image:
            image.load()
        return width, height
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Provider output PNG validation failed: {exc}")


def download_output(filename: str, subfolder: str, folder_type: str) -> bytes:
    params = {"filename": filename, "subfolder": subfolder, "type": folder_type}
    with requests.get(COMFY_URL + "/view", params=params, timeout=120, stream=True) as r:
        if r.status_code >= 400:
            raise HTTPException(status_code=502, detail=f"ComfyUI image download failed ({r.status_code})")
        length = r.headers.get("Content-Length")
        if length and int(length) > MAX_OUTPUT_BYTES:
            raise HTTPException(status_code=502, detail="ComfyUI output exceeds gateway size limit")
        out = bytearray()
        for chunk in r.iter_content(chunk_size=65536):
            if not chunk:
                continue
            out.extend(chunk)
            if len(out) > MAX_OUTPUT_BYTES:
                raise HTTPException(status_code=502, detail="ComfyUI output exceeds gateway size limit")
        if not out:
            raise HTTPException(status_code=502, detail="ComfyUI returned an empty image")
        result = bytes(out)
        validate_png_bytes(result)
        return result


@app.get("/jobs/{client_request_id}")
def job_status(client_request_id: str, x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    row = get_job(client_request_id)
    if not row:
        raise HTTPException(status_code=404, detail="Job not found")
    _, _, prompt_id, status, filename, subfolder, folder_type, created_at, updated_at = row
    return {"clientRequestId": client_request_id, "providerJobId": prompt_id or "", "status": status,
            "output": {"filename": filename, "subfolder": subfolder, "folderType": folder_type} if filename else None,
            "createdAt": created_at, "updatedAt": updated_at}


@app.get("/jobs/{client_request_id}/result")
def job_result(client_request_id: str, x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    row = get_job(client_request_id)
    if not row:
        raise HTTPException(status_code=404, detail="Job not found")
    _, _, prompt_id, status, filename, subfolder, folder_type, _, _ = row
    if status != "COMPLETED" or not filename:
        raise HTTPException(status_code=409, detail="Job does not have a completed result")
    result = download_output(filename, subfolder or "", folder_type or "output")
    return Response(content=result, media_type="image/png", headers={"X-Generation-Id": prompt_id or "", "X-Client-Request-Id": client_request_id})


@app.get("/health")
def health(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    try:
        r = comfy_get("/system_stats", timeout=10)
        if r.status_code >= 400:
            raise RuntimeError(r.text[:400])
        return {"ok": True, "comfyui": True, "version": "3.1.0"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"ComfyUI unavailable: {exc}")


@app.get("/capabilities")
def capabilities(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    return {
        "providerId": "comfyui-gateway",
        "supportedTasks": SUPPORTED_TASKS,
        "ratios": SUPPORTED_RATIOS,
        "negativePrompt": True,
        "exactVideoDurationSeconds": 0.0,
        "sourceImageRequiredFor": ["IMAGE_TO_IMAGE"],
        "sourceImageOptionalFor": ["TEXT_TO_IMAGE"],
    }


@app.get("/models")
def models(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    try:
        r = comfy_get("/object_info/CheckpointLoaderSimple", timeout=30)
        if r.status_code >= 400:
            raise RuntimeError(r.text[:400])
        obj = r.json()
        enum = obj.get("CheckpointLoaderSimple", {}).get("input", {}).get("required", {}).get("ckpt_name", [[]])[0]
        models_list = sorted(str(x) for x in enum)
        return {"models": models_list, "default": DEFAULT_MODEL}
    except Exception as exc:
        return JSONResponse(status_code=503, content={"detail": f"Unable to enumerate models: {exc}"})


@app.post("/generate")
async def generate(
    request: Request,
    task_id: str = Form("IMAGE_TO_IMAGE"),
    image: Optional[UploadFile] = File(default=None),
    prompt: str = Form(...),
    negative_prompt: str = Form(""),
    aspect_ratio: str = Form("1:1"),
    profile: str = Form("Balanced"),
    model: str = Form(""),
    preserve: int = Form(58),
    cfg: float = Form(7.8),
    steps: int = Form(36),
    seed: int = Form(0),
    output_format: str = Form("png"),
    client_request_id: str = Form(""),
    x_app_token: Optional[str] = Header(default=None),
):
    auth(x_app_token)
    rate_limit(request.client.host if request.client else "unknown")
    if task_id not in SUPPORTED_TASKS:
        raise HTTPException(status_code=400, detail=f"Unsupported task: {task_id}")
    if not prompt.strip():
        raise HTTPException(status_code=400, detail="Prompt is required")
    if len(prompt) > MAX_PROMPT_CHARS or len(negative_prompt) > MAX_PROMPT_CHARS:
        raise HTTPException(status_code=413, detail=f"Prompt fields exceed {MAX_PROMPT_CHARS} characters")
    if aspect_ratio not in SUPPORTED_RATIOS:
        raise HTTPException(status_code=400, detail="Unsupported aspect ratio")
    if output_format.lower() != "png":
        raise HTTPException(status_code=400, detail="Only PNG output is supported")
    if task_id == "IMAGE_TO_IMAGE" and image is None:
        raise HTTPException(status_code=400, detail="Image-to-Image requires a source image")
    if task_id == "TEXT_TO_IMAGE" and image is not None:
        # Client may send null only; silently ignoring an unexpected image could hide a mapping bug.
        raise HTTPException(status_code=400, detail="Text-to-Image must not include a source image")

    width, height = target_size(aspect_ratio)
    denoise, cfg, steps = profile_settings(profile, preserve, cfg, steps)
    chosen_model = model.strip() or DEFAULT_MODEL
    effective_seed = seed if seed >= 0 else int.from_bytes(os.urandom(8), "big") % 2**63

    image_bytes = None
    upload_name = None
    if image is not None:
        raw = await image.read()
        if not raw:
            raise HTTPException(status_code=400, detail="Source image is empty")
        if len(raw) > MAX_SOURCE_BYTES:
            raise HTTPException(status_code=413, detail="Source image is too large")
        image_bytes, upload_name = preprocess_image(raw, aspect_ratio)

    client_id = client_request_id.strip() or str(uuid.uuid4())
    if len(client_id) > MAX_CLIENT_REQUEST_ID_CHARS:
        raise HTTPException(status_code=413, detail=f"client_request_id exceeds {MAX_CLIENT_REQUEST_ID_CHARS} characters")
    if any(ord(ch) < 32 for ch in client_id):
        raise HTTPException(status_code=400, detail="client_request_id contains unsupported control characters")
    req_hash = request_hash(task_id, prompt.strip(), negative_prompt.strip(), aspect_ratio, profile, chosen_model, preserve, cfg, steps, effective_seed, image_bytes)

    existing = get_job(client_id)
    if existing is None:
        _, existing = claim_job(client_id, req_hash)
    if existing:
        _, existing_hash, existing_prompt_id, existing_status, existing_filename, existing_subfolder, existing_folder_type, _, _ = existing
        if not hmac.compare_digest(existing_hash, req_hash):
            raise HTTPException(status_code=409, detail="client_request_id was already used for a different request")
        if existing_status == "COMPLETED" and existing_filename:
            result = download_output(existing_filename, existing_subfolder or "", existing_folder_type or "output")
            return Response(content=result, media_type="image/png", headers={"X-Generation-Id": existing_prompt_id or "", "X-Client-Request-Id": client_id, "X-Idempotent-Replay": "true"})
        if existing_status in {"SUBMITTING", "UNKNOWN"}:
            raise HTTPException(status_code=409, detail="Existing job state is ambiguous; do not blindly resubmit. Inspect /jobs/{client_request_id}.")
        prompt_id = existing_prompt_id
    else:
        raise HTTPException(status_code=500, detail="Unable to reserve generation request")

    image_name = None
    if image_bytes is not None:
        image_name = upload_to_comfy(image_bytes, upload_name or f"i2i_{uuid.uuid4().hex}.png")

    graph = workflow_txt2img(prompt, negative_prompt.strip(), chosen_model, effective_seed, steps, cfg, width, height) \
        if task_id == "TEXT_TO_IMAGE" else \
        workflow_i2i(image_name, prompt, negative_prompt.strip(), chosen_model, effective_seed, steps, cfg, denoise, width, height)

    if not prompt_id:
        prompt_id = queue_prompt(graph, client_id)
        put_job(client_id, req_hash, "QUEUED", prompt_id=prompt_id)
    filename, subfolder, folder_type = wait_for_image(prompt_id)
    put_job(client_id, req_hash, "DOWNLOADING", prompt_id=prompt_id, filename=filename, subfolder=subfolder, folder_type=folder_type)
    result = download_output(filename, subfolder, folder_type)
    put_job(client_id, req_hash, "COMPLETED", prompt_id=prompt_id, filename=filename, subfolder=subfolder, folder_type=folder_type)
    return Response(content=result, media_type="image/png", headers={"X-Generation-Id": prompt_id, "X-Client-Request-Id": client_id})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host=HOST, port=PORT, reload=False)
