# ImageToImageAI V3.1.1 — APK-FIRST BUILD-READY

This package preserves the current real Android Studio project while applying targeted reliability, media-validation, idempotency, recovery and CI hardening. It is intended to be built into an installable APK by GitHub Actions or another networked Android build environment.

## Real surfaced capabilities

- TEXT_TO_IMAGE through the ComfyUI gateway.
- IMAGE_TO_IMAGE through the preserved ComfyUI graph.
- Negative prompt for the current adapter.
- 1:1, 9:16, 16:9, 4:5 and 3:4 ratios.
- Backend/model discovery.
- Persistent generation jobs/history and saved result assets.
- Save, Share, and Use-as-source.

Unsupported future tasks are not exposed as fake controls.

## Reliability hardening

The gateway now claims `clientRequestId` atomically before provider submission, preserves original job creation time, recognizes provider error states, validates output PNGs, validates numeric generation inputs and prevents blind duplicate submission after ambiguous network outcomes. The Android client and recovery worker also validate/reconcile ambiguous results and clean up failed MediaStore writes.

## Build paths

Two workflows are included. `.github/workflows/build-apk.yml` is the direct-source verification workflow. `.github/workflows/build-apk-archive.yml` is the phone-friendly archive-backed workflow expected when the ZIP is stored at repository root.

The archive-backed workflow extracts the exact ZIP into a clean runner workspace, checks source checksums/path safety/cleanliness, installs pinned backend test dependencies, verifies Android SDK 36, bootstraps and verifies Gradle 9.4.1, runs backend tests plus Android lint/unit tests, assembles the debug APK, inspects alignment/signing/package/version, records SHA-256 provenance, and uploads the APK/evidence.

## Verification truth

Static/contract verification in the preparation environment: **14/14 backend tests PASS**.

Full Android Gradle build in this preparation environment: **NOT VERIFIED** because the container lacks the Android SDK and cannot reach the network to bootstrap the missing Gradle wrapper JAR.

APK generation, installation/runtime smoke, Android 10 device testing and live ComfyUI generation are therefore **NOT VERIFIED** here.
