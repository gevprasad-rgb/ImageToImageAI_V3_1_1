package com.prasad.image2image.data;

import android.content.Context;

import androidx.room.Room;

import com.prasad.image2image.domain.GenerationJobState;
import com.prasad.image2image.domain.GenerationRequest;

public final class GenerationRepository {
    private static volatile GenerationRepository instance;
    private final AppDatabase db;
    private final Context context;

    private GenerationRepository(Context context) {
        this.context = context.getApplicationContext();
        this.db = Room.databaseBuilder(this.context, AppDatabase.class, "image_to_image_ai.db").build();
    }

    public static GenerationRepository getInstance(Context context) {
        if (instance == null) {
            synchronized (GenerationRepository.class) {
                if (instance == null) instance = new GenerationRepository(context);
            }
        }
        return instance;
    }

    public long ensureDefaultProject() {
        java.util.List<ProjectEntity> projects = db.projectDao().getAll();
        if (!projects.isEmpty()) return projects.get(0).id;
        long now = System.currentTimeMillis();
        return db.projectDao().insert(new ProjectEntity("My Project", now, now));
    }

    public long createJob(long projectId, GenerationRequest request) throws Exception {
        long now = System.currentTimeMillis();
        GenerationJobEntity entity = new GenerationJobEntity(
                projectId, request.clientRequestId, request.taskId.name(), request.providerId,
                request.model, request.prompt, request.negativePrompt,
                request.parametersJson(), request.sourceUri,
                GenerationJobState.CREATED.name(), now);
        return db.generationJobDao().insert(entity);
    }

    public void updateState(long jobId, GenerationJobState state, String error) {
        GenerationJobEntity entity = db.generationJobDao().findById(jobId);
        if (entity == null) return;
        GenerationJobState current;
        try { current = GenerationJobState.valueOf(entity.state); }
        catch (Exception ignored) { current = GenerationJobState.UNKNOWN; }
        if (!current.canTransitionTo(state)) throw new IllegalStateException("Invalid job transition: " + current + " -> " + state);
        entity.state = state.name();
        entity.errorMessage = error;
        entity.updatedAt = System.currentTimeMillis();
        db.generationJobDao().update(entity);
    }

    public void markCompleted(long jobId, String providerJobId, String resultPath,
                              int width, int height, String mimeType) {
        GenerationJobEntity entity = db.generationJobDao().findById(jobId);
        if (entity == null) return;
        entity.providerJobId = providerJobId;
        entity.resultPath = resultPath;
        entity.width = width;
        entity.height = height;
        entity.mimeType = mimeType;
        entity.errorMessage = null;
        entity.state = GenerationJobState.COMPLETED.name();
        entity.updatedAt = System.currentTimeMillis();
        db.generationJobDao().update(entity);
    }

    public GenerationJobEntity findJob(long jobId) {
        return db.generationJobDao().findById(jobId);
    }

    public java.util.List<GenerationJobEntity> recentJobs(int limit) {
        return db.generationJobDao().getRecent(limit);
    }

    public java.util.List<GenerationJobEntity> pendingJobs() {
        return db.generationJobDao().getPendingJobs();
    }
}
