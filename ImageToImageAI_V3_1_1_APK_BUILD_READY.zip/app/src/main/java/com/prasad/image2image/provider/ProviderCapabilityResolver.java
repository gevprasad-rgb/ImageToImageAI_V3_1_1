package com.prasad.image2image.provider;

import com.prasad.image2image.domain.ProviderCapability;
import com.prasad.image2image.domain.TaskId;

public final class ProviderCapabilityResolver {
    public boolean supports(ProviderAdapter adapter, TaskId taskId) throws Exception {
        ProviderCapability capability = adapter.getCapabilities();
        return capability.supports(taskId);
    }
}
