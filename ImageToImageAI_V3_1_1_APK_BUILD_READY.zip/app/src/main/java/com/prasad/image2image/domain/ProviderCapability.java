package com.prasad.image2image.domain;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class ProviderCapability {
    public final String providerId;
    public final Set<TaskId> supportedTasks;
    public final List<String> ratios;
    public final double exactVideoDurationSeconds;

    public ProviderCapability(String providerId, Set<TaskId> supportedTasks,
                              List<String> ratios, double exactVideoDurationSeconds) {
        this.providerId = providerId;
        this.supportedTasks = Collections.unmodifiableSet(new LinkedHashSet<>(supportedTasks));
        this.ratios = Collections.unmodifiableList(ratios);
        this.exactVideoDurationSeconds = exactVideoDurationSeconds;
    }

    public boolean supports(TaskId taskId) {
        return supportedTasks.contains(taskId);
    }
}
