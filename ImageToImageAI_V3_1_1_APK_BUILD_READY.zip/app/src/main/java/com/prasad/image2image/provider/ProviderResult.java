package com.prasad.image2image.provider;

public final class ProviderResult {
    public final byte[] bytes;
    public final String providerJobId;
    public final int width;
    public final int height;
    public final String mimeType;

    public ProviderResult(byte[] bytes, String providerJobId, int width, int height, String mimeType) {
        this.bytes = bytes;
        this.providerJobId = providerJobId;
        this.width = width;
        this.height = height;
        this.mimeType = mimeType;
    }
}
