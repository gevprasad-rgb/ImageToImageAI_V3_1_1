package com.prasad.image2image;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.exifinterface.media.ExifInterface;

import com.prasad.image2image.data.GenerationJobEntity;
import com.prasad.image2image.data.GenerationRepository;
import com.prasad.image2image.domain.GenerationJobState;
import com.prasad.image2image.domain.GenerationRequest;
import com.prasad.image2image.domain.TaskId;
import com.prasad.image2image.provider.ComfyUiProviderAdapter;
import com.prasad.image2image.provider.ProviderAdapter;
import com.prasad.image2image.provider.ProviderCapabilityResolver;
import com.prasad.image2image.provider.ProviderManager;
import com.prasad.image2image.provider.ProviderRegistry;
import com.prasad.image2image.provider.ProviderResult;
import com.prasad.image2image.provider.ProviderReconciliation;
import com.prasad.image2image.recovery.PendingJobRecoveryScheduler;
import com.prasad.image2image.security.SecureCredentialStore;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 1001;
    private static final int MAX_SIDE = 1536;
    private static final int MAX_UPLOAD_BYTES = 8_500_000;
    private static final int MAX_DECODE_SIDE = 2048;
    private static final String PREFS = "image_to_image_ai_preferences";
    private static final String PREF_BACKEND = "backend_url";
    private static final String PREF_TRUSTED_HTTP = "trusted_lan_http";
    private static final String DEFAULT_BACKEND = "";
    private static final String PROVIDER_ID = ComfyUiProviderAdapter.PROVIDER_ID;

    private ImageView sourcePreview, resultPreview;
    private EditText promptInput, negativePromptInput, seedInput, backendInput, tokenInput;
    private SeekBar preserveBar, cfgBar, stepsBar;
    private TextView preserveLabel, cfgLabel, stepsLabel, statusText, backendStatus;
    private ProgressBar progressBar;
    private Button generateButton, saveButton, shareButton, useResultButton, chooseButton,
            settingsButton, clearSourceButton, refreshModelsButton, historyButton;
    private Spinner taskSpinner, aspectSpinner, profileSpinner, modelSpinner, batchSpinner;
    private CheckBox trustedLanHttpCheck;

    private Uri sourceUri;
    private byte[] resultBytes;
    private String resultPath;
    private long currentJobId = -1L;
    private long defaultProjectId = -1L;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Random random = new Random();
    private GenerationRepository repository;
    private SecureCredentialStore credentials;
    private ProviderManager providerManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        repository = GenerationRepository.getInstance(this);
        credentials = new SecureCredentialStore(this);
        providerManager = new ProviderManager(new ProviderRegistry());
        bindViews();
        setupSpinners();
        setupControls();
        loadLastCompletedResult();
        updateBackendStatus(false, "Backend not checked");
        PendingJobRecoveryScheduler.schedule(this);
    }

    private void bindViews() {
        sourcePreview = findViewById(R.id.sourcePreview);
        resultPreview = findViewById(R.id.resultPreview);
        promptInput = findViewById(R.id.promptInput);
        negativePromptInput = findViewById(R.id.negativePromptInput);
        seedInput = findViewById(R.id.seedInput);
        backendInput = findViewById(R.id.backendInput);
        tokenInput = findViewById(R.id.tokenInput);
        trustedLanHttpCheck = findViewById(R.id.trustedLanHttpCheck);
        preserveBar = findViewById(R.id.preserveBar);
        cfgBar = findViewById(R.id.cfgBar);
        stepsBar = findViewById(R.id.stepsBar);
        preserveLabel = findViewById(R.id.preserveLabel);
        cfgLabel = findViewById(R.id.cfgLabel);
        stepsLabel = findViewById(R.id.stepsLabel);
        statusText = findViewById(R.id.statusText);
        backendStatus = findViewById(R.id.backendStatus);
        progressBar = findViewById(R.id.progressBar);
        generateButton = findViewById(R.id.generateButton);
        saveButton = findViewById(R.id.saveButton);
        shareButton = findViewById(R.id.shareButton);
        useResultButton = findViewById(R.id.useResultButton);
        chooseButton = findViewById(R.id.chooseButton);
        settingsButton = findViewById(R.id.settingsButton);
        clearSourceButton = findViewById(R.id.clearSourceButton);
        refreshModelsButton = findViewById(R.id.refreshModelsButton);
        historyButton = findViewById(R.id.historyButton);
        taskSpinner = findViewById(R.id.taskSpinner);
        aspectSpinner = findViewById(R.id.aspectSpinner);
        profileSpinner = findViewById(R.id.profileSpinner);
        modelSpinner = findViewById(R.id.modelSpinner);
        batchSpinner = findViewById(R.id.batchSpinner);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        backendInput.setText(prefs.getString(PREF_BACKEND, DEFAULT_BACKEND));
        trustedLanHttpCheck.setChecked(prefs.getBoolean(PREF_TRUSTED_HTTP, false));
        try { tokenInput.setText(credentials.getBackendToken()); }
        catch (Exception e) { tokenInput.setText(""); toast("Stored backend credential could not be opened; re-enter it"); }
    }

    private void setupSpinners() {
        setSpinner(taskSpinner, new String[]{"Text to Image", "Image to Image"});
        setSpinner(aspectSpinner, new String[]{"1:1", "9:16", "16:9", "4:5", "3:4"});
        setSpinner(profileSpinner, new String[]{"Balanced", "Source Preserve", "Creative Transform", "High Detail"});
        setSpinner(modelSpinner, new String[]{"Auto / Backend Default"});
        setSpinner(batchSpinner, new String[]{"1 image", "2 variations", "3 variations", "4 variations"});
    }

    private void setSpinner(Spinner spinner, String[] values) {
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values));
    }

    private void setupControls() {
        taskSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { updateTaskUi(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        preserveBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int p = Math.max(5, Math.min(95, progress));
                preserveLabel.setText("Source preservation  " + p + "%");
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });
        cfgBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                float value = Math.max(10, progress) / 10f;
                cfgLabel.setText(String.format(Locale.US, "Prompt adherence  %.1f", value));
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });
        stepsBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                stepsLabel.setText("Quality steps  " + (12 + progress));
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });
        chooseButton.setOnClickListener(v -> chooseImage());
        clearSourceButton.setOnClickListener(v -> clearSource());
        generateButton.setOnClickListener(v -> generate());
        saveButton.setOnClickListener(v -> saveResult());
        shareButton.setOnClickListener(v -> shareResult());
        useResultButton.setOnClickListener(v -> useResultAsSource());
        settingsButton.setOnClickListener(v -> testAndPersistBackend());
        refreshModelsButton.setOnClickListener(v -> refreshModels());
        historyButton.setOnClickListener(v -> showHistory());
        preserveBar.setProgress(58);
        cfgBar.setProgress(78);
        stepsBar.setProgress(24);
        updateTaskUi();
    }

    private void updateTaskUi() {
        boolean imageToImage = getSelectedTask() == TaskId.IMAGE_TO_IMAGE;
        findViewById(R.id.sourceCard).setVisibility(imageToImage ? View.VISIBLE : View.GONE);
        preserveBar.setEnabled(imageToImage);
        preserveLabel.setEnabled(imageToImage);
    }

    private TaskId getSelectedTask() {
        return taskSpinner.getSelectedItemPosition() == 0 ? TaskId.TEXT_TO_IMAGE : TaskId.IMAGE_TO_IMAGE;
    }

    private void chooseImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            sourceUri = data.getData();
            try { getContentResolver().takePersistableUriPermission(sourceUri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
            sourcePreview.setImageURI(sourceUri);
            sourcePreview.setVisibility(View.VISIBLE);
            clearSourceButton.setVisibility(View.VISIBLE);
            resultPreview.setVisibility(View.GONE);
            saveButton.setVisibility(View.GONE);
            shareButton.setVisibility(View.GONE);
            useResultButton.setVisibility(View.GONE);
            resultBytes = null;
            statusText.setText("Source image ready");
        }
    }

    private void clearSource() {
        sourceUri = null;
        sourcePreview.setImageDrawable(null);
        sourcePreview.setVisibility(View.GONE);
        clearSourceButton.setVisibility(View.GONE);
        statusText.setText("Choose a source image");
    }

    private void generate() {
        final TaskId task = getSelectedTask();
        if (task == TaskId.IMAGE_TO_IMAGE && sourceUri == null) { toast("Choose a source image first"); return; }

        final String prompt = promptInput.getText().toString().trim();
        if (prompt.isEmpty()) { toast("Enter a generation prompt"); return; }
        if (prompt.length() > 10_000) { toast("Prompt is too long (max 10,000 characters)"); return; }
        final String negativePrompt = negativePromptInput.getText().toString().trim();
        if (negativePrompt.length() > 10_000) { toast("Negative prompt is too long (max 10,000 characters)"); return; }

        final String backend;
        try { backend = validatedBackendUrl(); }
        catch (Exception e) { toast(e.getMessage()); return; }
        persistBackend(backend);

        final String ratio = String.valueOf(aspectSpinner.getSelectedItem());
        final String profile = String.valueOf(profileSpinner.getSelectedItem());
        final String model = String.valueOf(modelSpinner.getSelectedItem());
        final int batchCount = batchSpinner.getSelectedItemPosition() + 1;
        final int preserve = Math.max(5, Math.min(95, preserveBar.getProgress()));
        final float cfg = Math.max(1f, Math.min(10f, cfgBar.getProgress() / 10f));
        final int steps = Math.max(12, Math.min(60, 12 + stepsBar.getProgress()));
        final long seed = parseSeed();
        if (seed < 0 && seed != Long.MIN_VALUE) return;
        final long baseSeed = seed == Long.MIN_VALUE ? newSeed() : seed;
        final String sourceString = sourceUri == null ? "" : sourceUri.toString();

        setBusy(true, task == TaskId.TEXT_TO_IMAGE ? "Preparing text generation…" : "Preparing source…");
        executor.execute(() -> {
            ProviderAdapter adapter = new ComfyUiProviderAdapter(backend, safeToken());
            providerManager = new ProviderManager(new ProviderRegistry());
            providerManagerRegistry(adapter);
            try {
                if (!new ProviderCapabilityResolver().supports(adapter, task)) {
                    throw new Exception("Selected task is not supported by the configured provider");
                }
                defaultProjectId = repository.ensureDefaultProject();
                byte[] prepared = null;
                if (task == TaskId.IMAGE_TO_IMAGE) prepared = readAndPrepareImage(sourceUri, ratio);
                byte[] last = null;
                String lastResultPath = null;
                long lastJobId = -1L;
                for (int i = 0; i < batchCount; i++) {
                    final long requestSeed = baseSeed + i;
                    final String clientRequestId = UUID.randomUUID().toString();
                    GenerationRequest request = new GenerationRequest(
                            clientRequestId, task, PROVIDER_ID, prompt, negativePrompt, ratio, profile,
                            model, task == TaskId.TEXT_TO_IMAGE ? 95 : preserve, cfg, steps, requestSeed, sourceString);
                    long jobId = repository.createJob(defaultProjectId, request);
                    PendingJobRecoveryScheduler.scheduleAfterSubmissionWindow(this);
                    lastJobId = jobId;
                    currentJobId = jobId;
                    repository.updateState(jobId, GenerationJobState.VALIDATING, null);
                    if (task == TaskId.IMAGE_TO_IMAGE) repository.updateState(jobId, GenerationJobState.UPLOADING, null);
                    repository.updateState(jobId, GenerationJobState.GENERATING, null);
                    final int n = i + 1;
                    runOnUiThread(() -> statusText.setText("Generating " + taskLabel(task) + " " + n + " of " + batchCount + "…"));
                    try {
                        ProviderResult result = adapter.generate(request, prepared);
                        repository.updateState(jobId, GenerationJobState.PROCESSING, null);
                        validateOutputBytes(result.bytes);
                        repository.updateState(jobId, GenerationJobState.VALIDATING_OUTPUT, null);
                        String filePath = persistResultFile(jobId, result.bytes);
                        repository.markCompleted(jobId, result.providerJobId, filePath, result.width, result.height, result.mimeType);
                        last = result.bytes;
                        lastResultPath = filePath;
                        lastJobId = jobId;
                    } catch (java.io.IOException e) {
                        try {
                            ProviderReconciliation reconciliation = adapter.reconcile(clientRequestId);
                            if (reconciliation.status == ProviderReconciliation.Status.COMPLETED && reconciliation.result != null) {
                                ProviderResult recovered = reconciliation.result;
                                validateOutputBytes(recovered.bytes);
                                repository.updateState(jobId, GenerationJobState.PROCESSING, null);
                                repository.updateState(jobId, GenerationJobState.VALIDATING_OUTPUT, null);
                                String recoveredPath = persistResultFile(jobId, recovered.bytes);
                                repository.markCompleted(jobId, recovered.providerJobId, recoveredPath, recovered.width, recovered.height, recovered.mimeType);
                                last = recovered.bytes;
                                lastResultPath = recoveredPath;
                                lastJobId = jobId;
                                continue;
                            }
                        } catch (Exception ignored) {
                            // Preserve UNKNOWN below; no blind resubmission.
                        }
                        repository.updateState(jobId, GenerationJobState.UNKNOWN, "Network state is ambiguous; automatic resubmission was blocked.");
                        throw new Exception("Network result is ambiguous. The job was preserved as UNKNOWN; do not blindly resubmit.", e);
                    } catch (Exception e) {
                        repository.updateState(jobId, GenerationJobState.FAILED, friendlyError(e));
                        throw e;
                    }
                }
                final byte[] finalBytes = last;
                final long finalJobId = lastJobId;
                final String finalResultPath = lastResultPath;
                runOnUiThread(() -> {
                    currentJobId = finalJobId;
                    resultPath = finalResultPath;
                    showResult(finalBytes);
                });
            } catch (Exception e) {
                runOnUiThread(() -> setBusy(false, "Error: " + friendlyError(e)));
            }
        });
    }

    private void providerManagerRegistry(ProviderAdapter adapter) {
        ProviderRegistry registry = new ProviderRegistry();
        registry.register(adapter);
        providerManager = new ProviderManager(registry);
    }

    private long parseSeed() {
        String text = seedInput.getText().toString().trim();
        if (text.isEmpty() || "random".equalsIgnoreCase(text)) return Long.MIN_VALUE;
        try {
            long seed = Long.parseLong(text);
            if (seed < 0 || seed > 9_223_372_036_854_775_000L) {
                toast("Seed must be a non-negative whole number"); return -1;
            }
            return seed;
        } catch (NumberFormatException e) {
            toast("Seed must be a whole number or blank"); return -1;
        }
    }

    private long newSeed() {
        long value = random.nextLong();
        return value == Long.MIN_VALUE ? 0L : Math.abs(value);
    }

    private byte[] readAndPrepareImage(Uri uri, String ratio) throws Exception {
        Bitmap bitmap;
        int[] sourceBounds = readBounds(uri);
        int sample = 1;
        int maxSource = Math.max(sourceBounds[0], sourceBounds[1]);
        while (maxSource / (sample * 2) > MAX_DECODE_SIDE) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("Unable to open source image");
            bitmap = BitmapFactory.decodeStream(in, null, opts);
        }
        if (bitmap == null) throw new Exception("Unable to decode source image");

        bitmap = correctExifOrientation(uri, bitmap);
        Bitmap cropped = cropToRatio(bitmap, ratio);
        if (cropped != bitmap) bitmap.recycle();
        int[] target = targetSize(ratio);
        Bitmap resized = Bitmap.createScaledBitmap(cropped, target[0], target[1], true);
        if (resized != cropped) cropped.recycle();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int quality = 94;
        do {
            out.reset();
            if (!resized.compress(Bitmap.CompressFormat.JPEG, quality, out)) {
                resized.recycle(); throw new Exception("Unable to encode source image");
            }
            quality -= 5;
        } while (out.size() > MAX_UPLOAD_BYTES && quality >= 55);
        resized.recycle();
        if (out.size() > MAX_UPLOAD_BYTES) throw new Exception("Source image is too large to upload");
        return out.toByteArray();
    }

    private int[] readBounds(Uri uri) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null || BitmapFactory.decodeStream(in, null, bounds) == null || bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                throw new Exception("Unable to inspect source image dimensions");
            }
            if ((long) bounds.outWidth * bounds.outHeight > 80_000_000L) throw new Exception("Source image dimensions are too large");
            return new int[]{bounds.outWidth, bounds.outHeight};
        }
    }

    private Bitmap correctExifOrientation(Uri uri, Bitmap source) {
        try (InputStream exifStream = getContentResolver().openInputStream(uri)) {
            if (exifStream == null) return source;
            ExifInterface exif = new ExifInterface(exifStream);
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            Matrix matrix = new Matrix();
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90: matrix.postRotate(90); break;
                case ExifInterface.ORIENTATION_ROTATE_180: matrix.postRotate(180); break;
                case ExifInterface.ORIENTATION_ROTATE_270: matrix.postRotate(270); break;
                case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: matrix.setScale(-1, 1); break;
                case ExifInterface.ORIENTATION_FLIP_VERTICAL: matrix.setScale(1, -1); break;
                default: return source;
            }
            return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
        } catch (Exception ignored) { return source; }
    }

    private Bitmap cropToRatio(Bitmap source, String ratio) {
        float target;
        switch (ratio) {
            case "9:16": target = 9f / 16f; break;
            case "16:9": target = 16f / 9f; break;
            case "4:5": target = 4f / 5f; break;
            case "3:4": target = 3f / 4f; break;
            default: target = 1f;
        }
        float current = source.getWidth() / (float) source.getHeight();
        if (Math.abs(current - target) < 0.002f) return source;
        int width = source.getWidth(), height = source.getHeight();
        if (current > target) {
            int newWidth = Math.round(height * target);
            return Bitmap.createBitmap(source, (width - newWidth) / 2, 0, newWidth, height);
        }
        int newHeight = Math.round(width / target);
        return Bitmap.createBitmap(source, 0, (height - newHeight) / 2, width, newHeight);
    }

    private int[] targetSize(String ratio) {
        switch (ratio) {
            case "9:16": return new int[]{768, 1344};
            case "16:9": return new int[]{1344, 768};
            case "4:5": return new int[]{896, 1120};
            case "3:4": return new int[]{896, 1152};
            default: return new int[]{1024, 1024};
        }
    }

    private String persistResultFile(long jobId, byte[] bytes) throws Exception {
        File dir = new File(getFilesDir(), "assets/results");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Unable to create result asset directory");
        File file = new File(dir, "job_" + jobId + ".png");
        try (OutputStream out = new java.io.FileOutputStream(file)) { out.write(bytes); }
        return file.getAbsolutePath();
    }

    private void validateOutputBytes(byte[] bytes) throws Exception {
        if (bytes == null || bytes.length < 24) throw new Exception("Provider returned an invalid image");
        if ((bytes[0] & 0xff) != 0x89 || bytes[1] != 0x50 || bytes[2] != 0x4e || bytes[3] != 0x47) throw new Exception("Provider output is not a PNG");
        int width = ((bytes[16] & 0xff) << 24) | ((bytes[17] & 0xff) << 16) | ((bytes[18] & 0xff) << 8) | (bytes[19] & 0xff);
        int height = ((bytes[20] & 0xff) << 24) | ((bytes[21] & 0xff) << 16) | ((bytes[22] & 0xff) << 8) | (bytes[23] & 0xff);
        if (width <= 0 || height <= 0 || width > 8192 || height > 8192) throw new Exception("Provider output dimensions are invalid");
    }

    private void showResult(byte[] bytes) {
        resultBytes = bytes;
        resultPreview.setImageBitmap(decodePreview(bytes, MAX_SIDE));
        resultPreview.setVisibility(View.VISIBLE);
        saveButton.setVisibility(View.VISIBLE);
        shareButton.setVisibility(View.VISIBLE);
        useResultButton.setVisibility(View.VISIBLE);
        setBusy(false, "Generation complete");
    }

    private Bitmap decodePreview(byte[] bytes, int maxSide) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
        int sample = 1;
        int max = Math.max(bounds.outWidth, bounds.outHeight);
        while (max / (sample * 2) > maxSide) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = Math.max(1, sample);
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
    }

    private void useResultAsSource() {
        if (resultBytes == null) return;
        try {
            Uri uri = saveBytesToMediaStore(resultBytes, "ImageToImageAI_source_" + timestamp() + ".png");
            sourceUri = uri;
            sourcePreview.setImageBitmap(decodePreview(resultBytes, 900));
            sourcePreview.setVisibility(View.VISIBLE);
            clearSourceButton.setVisibility(View.VISIBLE);
            taskSpinner.setSelection(1);
            statusText.setText("Result is now the source image");
        } catch (Exception e) { toast("Could not use result as source: " + friendlyError(e)); }
    }

    private void saveResult() {
        if (resultBytes == null) return;
        try {
            saveBytesToMediaStore(resultBytes, "ImageToImageAI_V3_" + timestamp() + ".png");
            toast("Saved to Pictures/ImageToImageAI");
        } catch (Exception e) { toast("Save failed: " + friendlyError(e)); }
    }

    private Uri saveBytesToMediaStore(byte[] bytes, String displayName) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, displayName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ImageToImageAI");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
        }
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Unable to create media file");
        try {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new Exception("Unable to open media file");
                out.write(bytes);
            }
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            }
            return uri;
        } catch (Exception e) {
            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            throw e;
        }
    }

    private void shareResult() {
        if (resultBytes == null) return;
        try {
            Uri uri = saveBytesToMediaStore(resultBytes, "ImageToImageAI_share_" + timestamp() + ".png");
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/png");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "Share generated image"));
        } catch (Exception e) { toast("Share failed: " + friendlyError(e)); }
    }

    private void refreshModels() {
        final String backend;
        try { backend = validatedBackendUrl(); }
        catch (Exception e) { toast(e.getMessage()); return; }
        persistBackend(backend);
        setBusy(true, "Loading provider models…");
        executor.execute(() -> {
            try {
                ProviderAdapter adapter = new ComfyUiProviderAdapter(backend, safeToken());
                List<String> models = adapter.getModels();
                runOnUiThread(() -> {
                    ArrayList<String> values = new ArrayList<>();
                    values.add("Auto / Backend Default");
                    values.addAll(models);
                    setSpinner(modelSpinner, values.toArray(new String[0]));
                    setBusy(false, models.isEmpty() ? "Provider returned no checkpoint models" : (models.size() + " models available"));
                });
            } catch (Exception e) { runOnUiThread(() -> setBusy(false, "Model refresh failed: " + friendlyError(e))); }
        });
    }

    private void testAndPersistBackend() {
        final String backend;
        try { backend = validatedBackendUrl(); }
        catch (Exception e) { toast(e.getMessage()); return; }
        persistBackend(backend);
        setBusy(true, "Checking backend…");
        executor.execute(() -> {
            try {
                ProviderAdapter adapter = new ComfyUiProviderAdapter(backend, safeToken());
                adapter.healthCheck();
                runOnUiThread(() -> updateBackendStatus(true, "Backend online • " + backend));
                runOnUiThread(() -> setBusy(false, "Backend check complete"));
            } catch (Exception e) {
                runOnUiThread(() -> { updateBackendStatus(false, "Backend unavailable"); setBusy(false, "Backend check failed: " + friendlyError(e)); });
            }
        });
    }

    private void persistBackend(String backend) {
        try { credentials.putBackendToken(tokenInput.getText().toString().trim()); }
        catch (Exception e) { toast("Could not securely store backend token"); }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(PREF_BACKEND, backend)
                .putBoolean(PREF_TRUSTED_HTTP, trustedLanHttpCheck.isChecked())
                .apply();
    }

    private String safeToken() {
        try { return credentials.getBackendToken(); }
        catch (Exception e) { return tokenInput.getText().toString().trim(); }
    }

    private String validatedBackendUrl() throws Exception {
        String raw = backendInput.getText().toString().trim();
        if (raw.isEmpty()) throw new Exception("Set your backend URL in Settings");
        String normalized = normalizedBackendUrl(raw);
        URI uri;
        try { uri = new URI(normalized); }
        catch (URISyntaxException e) { throw new Exception("Backend URL is invalid"); }
        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (host == null) throw new Exception("Backend URL must include a host");
        if ("http".equalsIgnoreCase(scheme)) {
            if (!BuildConfig.DEBUG) throw new Exception("Release builds require HTTPS for backend connections");
            if (!trustedLanHttpCheck.isChecked()) throw new Exception("HTTP is blocked by default. Enable ‘Trusted LAN HTTP’ only for a private/local development backend.");
            if (!isTrustedLanHost(host)) throw new Exception("Trusted LAN HTTP allows only localhost or private IPv4 hosts; use HTTPS for public/remote endpoints.");
        }
        return normalized;
    }

    private String normalizedBackendUrl(String raw) throws Exception {
        String value = raw.trim();
        if (!(value.regionMatches(true, 0, "http://", 0, 7) || value.regionMatches(true, 0, "https://", 0, 8))) throw new Exception("Backend URL must start with http:// or https://");
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        return value;
    }

    private boolean isTrustedLanHost(String host) {
        if ("localhost".equalsIgnoreCase(host)) return true;
        String[] parts = host.split("\\.");
        if (parts.length != 4) return false;
        try {
            int a = Integer.parseInt(parts[0]), b = Integer.parseInt(parts[1]), c = Integer.parseInt(parts[2]), d = Integer.parseInt(parts[3]);
            if (a < 0 || a > 255 || b < 0 || b > 255 || c < 0 || c > 255 || d < 0 || d > 255) return false;
            return a == 10 || (a == 192 && b == 168) || (a == 172 && b >= 16 && b <= 31) || (a == 127);
        } catch (NumberFormatException e) { return false; }
    }

    private void showHistory() {
        setBusy(true, "Loading history…");
        executor.execute(() -> {
            try {
                List<GenerationJobEntity> jobs = repository.recentJobs(30);
                runOnUiThread(() -> {
                    setBusy(false, "History loaded");
                    if (jobs.isEmpty()) { new AlertDialog.Builder(this).setTitle("History").setMessage("No generations have been saved yet.").setPositiveButton("OK", null).show(); return; }
                    String[] labels = new String[jobs.size()];
                    for (int i = 0; i < jobs.size(); i++) {
                        GenerationJobEntity j = jobs.get(i);
                        labels[i] = new SimpleDateFormat("MMM d, HH:mm", Locale.US).format(new Date(j.createdAt)) +
                                " • " + j.taskId + " • " + j.state;
                    }
                    new AlertDialog.Builder(this).setTitle("Recent generations")
                            .setItems(labels, (dialog, which) -> openHistoryJob(jobs.get(which)))
                            .setNegativeButton("Close", null).show();
                });
            } catch (Exception e) { runOnUiThread(() -> setBusy(false, "History failed: " + friendlyError(e))); }
        });
    }

    private void openHistoryJob(GenerationJobEntity job) {
        if (job.resultPath == null || job.resultPath.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Generation")
                    .setMessage("State: " + job.state + "\n\n" + (job.errorMessage == null ? "No result asset is available." : job.errorMessage))
                    .setPositiveButton("OK", null).show();
            return;
        }
        File file = new File(job.resultPath);
        if (!file.isFile()) { toast("Saved result asset is missing"); return; }
        try {
            byte[] bytes = readFile(file);
            validateOutputBytes(bytes);
            currentJobId = job.id;
            resultPath = job.resultPath;
            showResult(bytes);
        } catch (Exception e) { toast("Could not reopen result: " + friendlyError(e)); }
    }

    private void loadLastCompletedResult() {
        executor.execute(() -> {
            try {
                List<GenerationJobEntity> jobs = repository.recentJobs(20);
                for (GenerationJobEntity job : jobs) {
                    if (!GenerationJobState.COMPLETED.name().equals(job.state) || job.resultPath == null) continue;
                    File file = new File(job.resultPath);
                    if (!file.isFile()) continue;
                    byte[] bytes = readFile(file);
                    validateOutputBytes(bytes);
                    final GenerationJobEntity found = job;
                    runOnUiThread(() -> {
                        currentJobId = found.id;
                        resultPath = found.resultPath;
                        resultBytes = bytes;
                        resultPreview.setImageBitmap(decodePreview(bytes, MAX_SIDE));
                        resultPreview.setVisibility(View.VISIBLE);
                        saveButton.setVisibility(View.VISIBLE);
                        shareButton.setVisibility(View.VISIBLE);
                        useResultButton.setVisibility(View.VISIBLE);
                        statusText.setText("Last result restored from history");
                    });
                    return;
                }
            } catch (Exception ignored) {}
        });
    }

    private byte[] readFile(File file) throws Exception {
        try (InputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toByteArray();
        }
    }

    private String timestamp() { return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()); }

    private String taskLabel(TaskId task) { return task == TaskId.TEXT_TO_IMAGE ? "Text→Image" : "Image→Image"; }

    private void updateBackendStatus(boolean online, String text) { backendStatus.setText((online ? "●  " : "○  ") + text); }

    private void setBusy(boolean busy, String message) {
        progressBar.setVisibility(busy ? View.VISIBLE : View.GONE);
        generateButton.setEnabled(!busy);
        chooseButton.setEnabled(!busy);
        settingsButton.setEnabled(!busy);
        refreshModelsButton.setEnabled(!busy);
        historyButton.setEnabled(!busy);
        statusText.setText(message);
    }

    private String friendlyError(Exception e) {
        Throwable t = e;
        while (t.getCause() != null && t.getCause() != t) t = t.getCause();
        String message = t.getMessage();
        return message == null || message.trim().isEmpty() ? t.getClass().getSimpleName() : message;
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
