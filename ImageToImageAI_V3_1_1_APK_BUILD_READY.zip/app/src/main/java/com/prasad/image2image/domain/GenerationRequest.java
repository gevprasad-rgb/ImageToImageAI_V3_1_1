package com.prasad.image2image.domain;

import org.json.JSONException;
import org.json.JSONObject;

public final class GenerationRequest {
    public final String clientRequestId;
    public final TaskId taskId;
    public final String providerId;
    public final String prompt;
    public final String negativePrompt;
    public final String aspectRatio;
    public final String profile;
    public final String model;
    public final int preserve;
    public final float cfg;
    public final int steps;
    public final long seed;
    public final String sourceUri;

    public GenerationRequest(String clientRequestId, TaskId taskId, String providerId,
                             String prompt, String negativePrompt, String aspectRatio,
                             String profile, String model, int preserve, float cfg,
                             int steps, long seed, String sourceUri) {
        this.clientRequestId = clientRequestId;
        this.taskId = taskId;
        this.providerId = providerId;
        this.prompt = prompt;
        this.negativePrompt = negativePrompt;
        this.aspectRatio = aspectRatio;
        this.profile = profile;
        this.model = model;
        this.preserve = preserve;
        this.cfg = cfg;
        this.steps = steps;
        this.seed = seed;
        this.sourceUri = sourceUri;
    }

    public String parametersJson() throws JSONException {
        JSONObject json = new JSONObject();
        json.put("aspectRatio", aspectRatio);
        json.put("profile", profile);
        json.put("model", model);
        json.put("preserve", preserve);
        json.put("cfg", cfg);
        json.put("steps", steps);
        json.put("seed", seed);
        return json.toString();
    }
}
