package com.prasad.image2image.provider;

import com.prasad.image2image.domain.GenerationRequest;
import com.prasad.image2image.domain.ProviderCapability;
import com.prasad.image2image.domain.TaskId;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class ComfyUiProviderAdapter implements ProviderAdapter {
    public static final String PROVIDER_ID = "comfyui-gateway";
    private static final int MAX_RESPONSE_BYTES = 25_000_000;
    private final String backend;
    private final String token;

    public ComfyUiProviderAdapter(String backend, String token) {
        this.backend = backend;
        this.token = token == null ? "" : token.trim();
    }

    @Override public String getProviderId() { return PROVIDER_ID; }

    @Override
    public ProviderCapability getCapabilities() throws Exception {
        HttpURLConnection c = open("/capabilities", "GET");
        try {
            int code = c.getResponseCode();
            byte[] body = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code != 200) throw httpError(code, body);
            JSONObject root = new JSONObject(new String(body, StandardCharsets.UTF_8));
            LinkedHashSet<TaskId> tasks = new LinkedHashSet<>();
            JSONArray supported = root.optJSONArray("supportedTasks");
            if (supported != null) {
                for (int i = 0; i < supported.length(); i++) {
                    try { tasks.add(TaskId.valueOf(supported.optString(i))); }
                    catch (Exception ignored) {}
                }
            }
            ArrayList<String> ratios = new ArrayList<>();
            JSONArray ratioArray = root.optJSONArray("ratios");
            if (ratioArray != null) for (int i = 0; i < ratioArray.length(); i++) ratios.add(ratioArray.optString(i));
            return new ProviderCapability(PROVIDER_ID, tasks, ratios, root.optDouble("exactVideoDurationSeconds", 0.0));
        } finally { c.disconnect(); }
    }

    @Override
    public List<String> getModels() throws Exception {
        HttpURLConnection c = open("/models", "GET");
        try {
            int code = c.getResponseCode();
            byte[] body = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code != 200) throw httpError(code, body);
            JSONObject root = new JSONObject(new String(body, StandardCharsets.UTF_8));
            ArrayList<String> out = new ArrayList<>();
            JSONArray models = root.optJSONArray("models");
            if (models != null) for (int i = 0; i < models.length(); i++) out.add(models.optString(i));
            return out;
        } finally { c.disconnect(); }
    }

    @Override
    public void healthCheck() throws Exception {
        HttpURLConnection c = open("/health", "GET");
        try {
            int code = c.getResponseCode();
            byte[] body = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code != 200) throw httpError(code, body);
        } finally { c.disconnect(); }
    }

    @Override
    public ProviderReconciliation reconcile(String clientRequestId) throws Exception {
        String encoded = URLEncoder.encode(clientRequestId, StandardCharsets.UTF_8.name());
        HttpURLConnection status = open("/jobs/" + encoded, "GET");
        try {
            int code = status.getResponseCode();
            byte[] body = readAll(code >= 400 ? status.getErrorStream() : status.getInputStream());
            if (code == 404) return ProviderReconciliation.notFound();
            if (code != 200) throw httpError(code, body);
            JSONObject root = new JSONObject(new String(body, StandardCharsets.UTF_8));
            String state = root.optString("status", "UNKNOWN");
            String providerJobId = root.optString("providerJobId", "");
            if ("COMPLETED".equalsIgnoreCase(state)) {
                HttpURLConnection resultConn = open("/jobs/" + encoded + "/result", "GET");
                try {
                    int resultCode = resultConn.getResponseCode();
                    byte[] resultBody = readAll(resultCode >= 400 ? resultConn.getErrorStream() : resultConn.getInputStream());
                    if (resultCode != 200) throw httpError(resultCode, resultBody);
                    if (resultBody.length == 0) throw new Exception("Reconciled provider result is empty");
                    int[] dims = sniffPngDimensions(resultBody);
                    return ProviderReconciliation.completed(new ProviderResult(resultBody, providerJobId, dims[0], dims[1], "image/png"));
                } finally { resultConn.disconnect(); }
            }
            if ("QUEUED".equalsIgnoreCase(state) || "DOWNLOADING".equalsIgnoreCase(state)) {
                return ProviderReconciliation.pending(providerJobId);
            }
            if ("SUBMITTING".equalsIgnoreCase(state) || "UNKNOWN".equalsIgnoreCase(state)) {
                return ProviderReconciliation.ambiguous(providerJobId);
            }
            return ProviderReconciliation.pending(providerJobId);
        } finally { status.disconnect(); }
    }

    @Override
    public ProviderResult generate(GenerationRequest request, byte[] sourceImage) throws Exception {
        String boundary = "----I2IV3" + UUID.randomUUID();
        HttpURLConnection c = open("/generate", "POST");
        c.setDoOutput(true);
        c.setConnectTimeout(30_000);
        c.setReadTimeout(900_000);
        c.setRequestProperty("Accept", "image/png");
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try {
            try (OutputStream out = c.getOutputStream()) {
                writeText(out, boundary, "task_id", request.taskId.name());
                writeText(out, boundary, "prompt", request.prompt);
                writeText(out, boundary, "negative_prompt", request.negativePrompt);
                writeText(out, boundary, "aspect_ratio", request.aspectRatio);
                writeText(out, boundary, "profile", request.profile);
                if (!request.model.startsWith("Auto /")) writeText(out, boundary, "model", request.model);
                writeText(out, boundary, "preserve", Integer.toString(request.preserve));
                writeText(out, boundary, "cfg", String.format(Locale.US, "%.1f", request.cfg));
                writeText(out, boundary, "steps", Integer.toString(request.steps));
                writeText(out, boundary, "seed", Long.toString(request.seed));
                writeText(out, boundary, "output_format", "png");
                writeText(out, boundary, "client_request_id", request.clientRequestId);
                if (sourceImage != null) writeFile(out, boundary, "image", "source.png", "image/png", sourceImage);
                out.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            byte[] body = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code != 200) throw httpError(code, body);
            if (body.length == 0) throw new Exception("Provider returned an empty image");
            int[] dims = sniffPngDimensions(body);
            String jobId = c.getHeaderField("X-Generation-Id");
            return new ProviderResult(body, jobId == null ? "" : jobId, dims[0], dims[1], "image/png");
        } finally { c.disconnect(); }
    }

    private HttpURLConnection open(String path, String method) throws Exception {
        URL url = new URL(backend + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod(method);
        c.setUseCaches(false);
        c.setInstanceFollowRedirects(false);
        if (!token.isEmpty()) c.setRequestProperty("X-App-Token", token);
        return c;
    }

    private Exception httpError(int code, byte[] body) {
        String msg = new String(body == null ? new byte[0] : body, StandardCharsets.UTF_8);
        try { msg = new JSONObject(msg).optString("detail", msg); } catch (Exception ignored) {}
        if (msg.length() > 500) msg = msg.substring(0, 500) + "…";
        if (code == 401) return new Exception("Backend access token rejected");
        if (code == 429) return new Exception("Backend queue is busy; try again shortly");
        if (code >= 500) return new IOException("Backend HTTP " + code + (msg.trim().isEmpty() ? "" : ": " + msg));
        return new Exception("Backend HTTP " + code + (msg.trim().isEmpty() ? "" : ": " + msg));
    }

    private void writeText(OutputStream out, String boundary, String name, String value) throws Exception {
        String safe = value == null ? "" : value;
        String s = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + safe + "\r\n";
        out.write(s.getBytes(StandardCharsets.UTF_8));
    }

    private void writeFile(OutputStream out, String boundary, String name, String filename, String mime, byte[] data) throws Exception {
        String s = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"; filename=\"" + filename + "\"\r\nContent-Type: " + mime + "\r\n\r\n";
        out.write(s.getBytes(StandardCharsets.UTF_8));
        out.write(data);
        out.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }

    private byte[] readAll(InputStream in) throws Exception {
        if (in == null) return new byte[0];
        try (InputStream input = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            int total = 0;
            while ((n = input.read(buf)) != -1) {
                total += n;
                if (total > MAX_RESPONSE_BYTES) throw new Exception("Provider response exceeds the 25 MB safety limit");
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    private int[] sniffPngDimensions(byte[] png) throws Exception {
        if (png.length < 24 || (png[0] & 0xff) != 0x89 || png[1] != 0x50 || png[2] != 0x4e || png[3] != 0x47) {
            throw new Exception("Provider output is not a valid PNG");
        }
        int width = ((png[16] & 0xff) << 24) | ((png[17] & 0xff) << 16) | ((png[18] & 0xff) << 8) | (png[19] & 0xff);
        int height = ((png[20] & 0xff) << 24) | ((png[21] & 0xff) << 16) | ((png[22] & 0xff) << 8) | (png[23] & 0xff);
        if (width <= 0 || height <= 0 || width > 8192 || height > 8192) throw new Exception("Provider output dimensions are invalid");
        return new int[]{width, height};
    }
}
