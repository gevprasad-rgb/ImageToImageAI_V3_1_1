package com.prasad.image2image.provider;

public final class ProviderManager {
    private final ProviderRegistry registry;

    public ProviderManager(ProviderRegistry registry) {
        this.registry = registry;
    }

    public ProviderAdapter adapter(String providerId) {
        return registry.get(providerId);
    }
}
