package com.prasad.image2image.domain;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class GenerationRequestTest {
    @Test public void parametersContainStableFields() throws Exception {
        GenerationRequest request = new GenerationRequest(
                "req-1", TaskId.IMAGE_TO_IMAGE, "comfyui-gateway", "a cat", "bad",
                "1:1", "Balanced", "Auto / Backend Default", 58, 7.8f, 36, 123L, "content://source");
        String json = request.parametersJson();
        assertTrue(json.contains("\"aspectRatio\":\"1:1\""));
        assertTrue(json.contains("\"seed\":123"));
    }
}
