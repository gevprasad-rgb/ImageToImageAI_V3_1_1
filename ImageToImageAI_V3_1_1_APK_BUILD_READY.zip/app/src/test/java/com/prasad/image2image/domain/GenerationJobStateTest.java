package com.prasad.image2image.domain;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class GenerationJobStateTest {
    @Test public void completedIsTerminal() {
        assertFalse(GenerationJobState.COMPLETED.canTransitionTo(GenerationJobState.RETRYING));
    }

    @Test public void networkLossCanBecomeUnknownAndThenRetry() {
        assertTrue(GenerationJobState.GENERATING.canTransitionTo(GenerationJobState.UNKNOWN));
        assertTrue(GenerationJobState.UNKNOWN.canTransitionTo(GenerationJobState.RETRYING));
        assertTrue(GenerationJobState.RETRYING.canTransitionTo(GenerationJobState.GENERATING));
    }

    @Test public void createdCannotJumpDirectlyToCompleted() {
        assertFalse(GenerationJobState.CREATED.canTransitionTo(GenerationJobState.COMPLETED));
    }
}
