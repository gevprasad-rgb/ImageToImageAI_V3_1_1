# GitHub Upload Contract — ImageToImageAI V3.1.1

## Phone-friendly archive build

Create/use a private GitHub repository with exactly these root inputs:

```text
ImageToImageAI_V3_1_1_BUILD3.zip
.github/workflows/build-apk-archive.yml
```

The ZIP must stay intact at repository root. Do not extract its source files into the repository for the archive-backed workflow. The workflow extracts and audits the exact archive inside the ephemeral GitHub Actions runner.

The package also contains the same archive-backed workflow at `.github/workflows/build-apk-archive.yml` plus a manual direct-source workflow at `.github/workflows/build-apk.yml`.

## Preservation

Keep the previous known-good source ZIP separately before replacing it. Do not delete the only backup.

## Build output

The workflow produces a verified debug APK artifact and SHA-256/provenance evidence. It does not create a signed release APK, because signing keys/secrets are intentionally not embedded in source.

## Gradle Wrapper

The original supplied source did not contain `gradle-wrapper.jar`. The final source keeps the official checksum and corrects `gradlew`/`gradlew.bat` to bootstrap the official Gradle v9.4.1 wrapper JAR from the official Gradle source URL, then verifies the published checksum. Therefore the ZIP remains network-buildable but is not offline-self-contained.

## Verification truth

A green GitHub Actions run proves the declared CI build/inspection gates. It does not prove device runtime smoke or live provider generation. Those require an actual Android device/emulator and a configured ComfyUI backend.
