# ImageToImageAI V3.1.1 — BUILD-READY Provenance

Target identity: versionCode 32 / versionName 3.1.1.
Application ID: com.prasad.image2image.
Android: minSdk 29, compileSdk 36, targetSdk 36.
Build toolchain contract: AGP 9.2.0 / Gradle 9.4.1 / JDK 17.

## Source preservation and hardening

The preserved BUILD3 application/provider/persistence paths remain intact. The final package adds targeted reliability/security fixes only: atomic gateway idempotency claim, provider terminal-error detection, strict PNG validation, input-range validation, safe HTTP ambiguity handling, recovery-state gating, MediaStore cleanup, correct PNG multipart declaration, corrected Gradle wrapper bootstrap URL, and the missing archive-backed CI workflow.

No new unsupported UI capability is surfaced. The current provider declares only TEXT_TO_IMAGE and IMAGE_TO_IMAGE. Video and other future tasks remain absent/unsupported rather than fake.

## Gradle Wrapper

- `gradle-wrapper.properties` pins Gradle 9.4.1 and the published distribution SHA-256.
- `gradle/wrapper/gradle-wrapper.jar.sha256` records the published official wrapper JAR SHA-256.
- The supplied source baseline did not include `gradle-wrapper.jar`; the package therefore bootstraps the official wrapper JAR only when a networked build environment is available.
- `gradlew` and `gradlew.bat` use the official Gradle v9.4.1 wrapper JAR source URL and verify SHA-256 `55243ef57851f12b070ad14f7f5bb8302daceeebc5bce5ece5fa6edb23e1145c` before execution.
- This source ZIP is not offline-self-contained because the wrapper JAR is intentionally not embedded.

## CI action provenance

- actions/checkout v7.0.1 → `3d3c42e5aac5ba805825da76410c181273ba90b1`
- actions/setup-java v6.0.1 → `de7274f081f381c8f8158605e0321c36c376e2e6`
- actions/setup-python v7.0.0 → `5fda3b95a4ea91299a34e894583c3862153e4b97`
- actions/upload-artifact v7.0.1 → `043fb46d1a93c77aae656e7c1c64a875d1fc6a0a`

## Verification evidence

PASS: 14 backend contract/integration tests
PASS: Python compileall
PASS: XML parse checks
PASS: Java structural delimiter checks
PASS: Bash syntax checks
PASS: CI YAML parse checks
PASS: stale-artifact cleanup and source-tree audit
PASS: source checksum manifest regeneration

NOT VERIFIED in this container: full Android Gradle build, APK creation/inspection, device installation/runtime smoke, and live provider generation.
